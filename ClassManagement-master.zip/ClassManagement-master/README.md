ClassManagement
===============

A classroom management system I wrote in PHP
