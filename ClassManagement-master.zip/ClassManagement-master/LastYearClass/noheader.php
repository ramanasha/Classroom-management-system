<?
	echo "<HTML>";
	echo "<HEAD>";
	echo "<TITLE>$page_title</TITLE>";
	echo '<link href="http://www.kweaver.net/class/style.css" rel="stylesheet" type="text/css">';
	echo "</HEAD>";
	echo "<BODY>";
?>
