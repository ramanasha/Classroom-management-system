<?
//login 
$page_title="Login to Mrs. Weaver's ClassRoom Site";
include 'header.php';
ini_set('include_path', '/home/kweavus/public_html/class');
include 'db.php';
include 'forms/login_form.html';
?>