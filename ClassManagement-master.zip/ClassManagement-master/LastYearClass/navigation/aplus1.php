<?
session_start();
$page_title="A Plus Materials";
ini_set('include_path', '/home/kweavus/public_html/class');
include 'header.php';
include 'sessionchecker.php';
session_checker();	
?>

<p>A Plus Material</p>
  <UL>
  		<li>oa Syntax Output
  		  <ul>
  		    <li>Instruction
  		        <ul>
  		          <li><a href="http://www.kweaver.net/class/readfile.php?path=/textbooks/APlus/slidesandjavacode/0a.syntaxoutput/0a.syntaxoutput.ppt">Powerpoint</a></li>
  		          <li><a href="http://www.kweaver.net/class/readfile.php?path=/textbooks/APlus/slidesandjavacode/0a.syntaxoutput/One.java">One.Java</a></li>
  		          <li><a href="http://www.kweaver.net/class/readfile.php?path=/textbooks/APlus/slidesandjavacode/0a.syntaxoutput/Two.java">Two.Java</a></li>
  		          <li><a href="http://www.kweaver.net/class/readfile.php?path=/textbooks/APlus/slidesandjavacode/0a.syntaxoutput/Three.java">Three.Java</a></li>
  		          <li><a href="http://www.kweaver.net/class/readfile.php?path=/textbooks/APlus/slidesandjavacode/0a.syntaxoutput/CompSci.java">CompSci.Java</a></li>
              </ul>
	        </li>
  		    <li>Labs</li>
			<UL>
			<li><a href="http://www.kweaver.net/class/readfile.php?path=/textbooks/APlus/labs/lab01/lab01a.doc">lab01a Instructions</a></li>
			<li><a href="http://www.kweaver.net/class/readfile.php?path=/textbooks/APlus/labs/lab01/lab01a.java">lab01a Source</a></li>
			<li><a href="http://www.kweaver.net/class/readfile.php?path=/textbooks/APlus/labs/lab01/lab01b.doc">lab01b Instructions</a></li>
			<li><a href="http://www.kweaver.net/class/readfile.php?path=/textbooks/APlus/labs/lab01/lab01b.java">lab01b Source</a></li>
			<li><a href="http://www.kweaver.net/class/readfile.php?path=/textbooks/APlus/labs/lab01/lab01c.doc">lab01c Instructions</a></li>
			<li><a href="http://www.kweaver.net/class/readfile.php?path=/textbooks/APlus/labs/lab01/lab01c.java">lab01c Source</a></li>
			</UL>
  		    <li>Worksheets
  		      <ul>
  		        <li><a href="http://www.kweaver.net/class/readfile.php?path=/textbooks/APlus/worksheets//0a.javatest/javatestworksheet.doc">JavaTest Worksheet</a></li>
	            <li><a href="http://www.kweaver.net/class/readfile.php?path=/textbooks/APlus/worksheets//0a.output/outputworksheet.doc">Output Worksheet</a></li>
  		        <li><a href="http://www.kweaver.net/class/readfile.php?path=/textbooks/APlus/worksheets//0a.output/syntaxoutput.doc">Syntax Output Worksheet</a></li>
  		      </ul>
	      </ul>
    </ul>
<?
include 'footer.php';
?>