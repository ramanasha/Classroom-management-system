<? 
	echo "<ul>";
	echo "<li><a href='http://www.kweaver.net/class/cal.php'>Daily Schedule</a></li>";
	echo "<li><a href='http://www.kweaver.net/class/sixweeks.php'>Six Weeks Schedule</a></li>";
	echo "<li><a href='http://www.kweaver.net/class/user/change_psw.html'>Change Password</a></li>";
	echo "<li><a href='http://www.kweaver.net/class/user/change_info.php'>Change Information</a></li>";
	echo "<li><a href='http://www.gradebookwizard.com/'>Gradebook</a></li>";
	echo "</ul>";
?>