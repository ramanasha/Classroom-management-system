<? 
echo "<ul>";
echo "<li><a href='http://www.kweaver.net/class/cal.php'>Daily Student Schedule</a></li>";
echo "<li><a href='http://www.kweaver.net/class/user/change_psw.html'>Change Password</a></li>";
echo "<li><a href='http://www.kweaver.net/class/user/change_info.php'>Change Information</a></li>";
echo "</ul>";
?>