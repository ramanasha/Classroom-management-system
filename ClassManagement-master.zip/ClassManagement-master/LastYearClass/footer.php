<? 
	include '/home/kweavus/public_html/class/navigation/navigation.php';
	echo "<br><center><a href=http://www.kweaver.net/class/logout.php>Logout</a></center>";
?>
</td>
</tr>

</table>
</div>