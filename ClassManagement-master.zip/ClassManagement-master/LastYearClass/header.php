<?
	echo "<HTML>";
	echo "<HEAD>";
	echo "<TITLE>$page_title</TITLE>";
	echo '<link href="http://www.kweaver.net/class/style.css" rel="stylesheet" type="text/css">';
?>
	<script language="Javascript1.2"><!-- // load htmlarea
	_editor_url = "/htmlarea/";                     // URL to htmlarea files
	var win_ie_ver = parseFloat(navigator.appVersion.split("MSIE")[1]);
	if (navigator.userAgent.indexOf('Mac')        >= 0) { win_ie_ver = 0; }
	if (navigator.userAgent.indexOf('Windows CE') >= 0) { win_ie_ver = 0; }
	if (navigator.userAgent.indexOf('Opera')      >= 0) { win_ie_ver = 0; }
	if (win_ie_ver >= 5.5) {
	  document.write('<scr' + 'ipt src="' +_editor_url+ 'editor.js"');
	  document.write(' language="Javascript1.2"></scr' + 'ipt>');  
	} else { document.write('<scr'+'ipt>function editor_generate() { return false; }</scr'+'ipt>'); }
	// --></script>
	</HEAD>
	<BODY>
	<div id="main">
	<table border="0" cellspacing="0" width="780" id="AutoNumber1" cellpadding="0">
	<tr>
	<td width="100%" colspan="2"><img border="0" src="http://www.kweaver.net/class/forms/Layer.gif"></td>
	</tr>
	<tr>
	<td width="155" valign="top" background="http://www.kweaver.net/class/forms/sliver.gif"></td>
	<td width="677">